<!--
Use this template to report a bug or ask a question.
Before you submit your issue, please provide as much information as possible.
-->
### Configuration

 - **Operating system with version** : 
 - **Node version**: 
 - **Hexo version**: 
 - **Hexo-cli version**: 
 - **Tranquilpeak version**: <!-- Does the theme is original or modified? -->
 - **Site configuration file** (Optional):
 - **Theme configuration file** (Optional):
 - **Hexo plugin** (Optional): <!-- run `npm ls --depth 0` at the root of your blog -->
 
### Actual behavior


### Expected behavior


### Steps to reproduce the behavior

